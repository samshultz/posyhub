﻿CKEDITOR.plugins.setLang( 'toc', 'de', {
	tooltip : 'Inhaltvsverzeichnis erstellen',
	notitles: 'Keine Überschriften vorhanden! \nBitte formatieren Sie diese als "Überschrift", "Überschrift 2" etc. im Editor',
	ToC: 'Inhaltsverzeichnis'
});
